# SKIP VERIFICATION (TEMPORARY)

Deze versie SKIPT de verificatie zodat je verder kunt!

## INSTALLATIE

cd C:\Projects\life_legacy_manager

copy SKIP_VERIFY\verify_recovery_phrase_screen.dart lib\modules\auth\screens\

# Hot reload: druk 'r' in console
# OF restart

Nu kun je registreren zonder verificatie!
We fixen de echte verificatie later.
